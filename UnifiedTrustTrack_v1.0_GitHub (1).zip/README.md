# Unified TrustTrack — Baseline v1.0

## Overview

Unified TrustTrack is a single-camera pedestrian multi-object
tracker integrating:

- V16 YOLO11n pedestrian detection
- V17 ResNet-18 identity embeddings
- V17 temporal Transformer association
- Constant-velocity motion prediction
- Persistent track states
- Heuristic trust-controlled memory updates
- Active, occluded and dormant track management
- Hungarian one-to-one assignment

This release preserves the original verified modular tracker.
The detector and tracker have NOT been jointly trained end-to-end.

## Execution

Run in a Python environment with the recorded dependencies.

```bash
python run_tracking.py \
  --input /path/to/MOT17-09-FRCNN/img1 \
  --output /path/to/output \
  --config final_inference_config.json
```

The command can also accept a supported video file as input.

Run it from the final_implementation directory, or provide
absolute paths to the script and configuration.

## Outputs

- tracks.csv: frame, track ID and normalized bounding box
- motchallenge.txt: MOTChallenge 10-column prediction format
- summary.json: tracking counts and lifecycle statistics

## Validation

Standalone regression tests passed against previously verified
trajectories on MOT17-09 and MOT17-13.

Both sequences reproduced identical frame/track IDs and
bounding boxes, with zero maximum difference.

## Evaluation

Local TrackEval on MOT17-09-FRCNN and MOT17-13-FRCNN:

- Combined HOTA: 38.970
- Combined DetA: 38.795
- Combined AssA: 39.743
- Combined MOTA: 37.974
- Combined IDF1: 47.783
- Combined IDSW: 250
- Combined Frag: 467

These are local development-subset results, not official
MOTChallenge test-server results.

## Reproducibility

See release/release_manifest.json for source and checkpoint
SHA-256 hashes, and release/requirements.txt for versions.

Checkpoint paths in final_inference_config.json refer to the
original Google Drive locations. Update those paths when
deploying elsewhere, and verify their hashes before use.

## Known limitations

- Identity memory is not yet used directly in association scoring.
- Trust-controlled memory updates are heuristic.
- Dormant reactivation counts do not guarantee correct identity recovery.
- The modular detector and tracker are not jointly trained.
- Additional ablations and independent benchmark evaluation remain.

## Optimization policy

Baseline v1.0 should remain unchanged. Future improvements
must be evaluated against this preserved release.
