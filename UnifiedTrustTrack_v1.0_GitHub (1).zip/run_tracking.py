
import argparse
import sys
import json
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from PIL import Image
from torchvision import transforms
from ultralytics import YOLO

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / "src"))

from unified_components import (
    TrustTrackIdentityEncoder,
    TrustTrackV11,
    TrustTrackV13,
    UnifiedTrustTrack
)

def load_pipeline(config_path):
    with open(config_path, "r") as f:
        cfg = json.load(f)

    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    detector_path = Path(cfg["detector"])
    model_path = Path(cfg["identity_temporal_checkpoint"])

    assert detector_path.exists(), detector_path
    assert model_path.exists(), model_path

    detector = YOLO(str(detector_path))

    identity = TrustTrackIdentityEncoder(
        embedding_dim=128
    )

    temporal = TrustTrackV11(
        embedding_dim=128,
        hidden_dim=128
    )

    model = TrustTrackV13(
        identity, temporal
    ).to(device)

    checkpoint = torch.load(
        model_path,
        map_location="cpu",
        weights_only=True
    )

    model.load_state_dict(
        checkpoint["model_state_dict"],
        strict=True
    )

    model.eval()

    preprocess = transforms.Compose([
        transforms.Resize((256, 128)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )
    ])

    tracker = UnifiedTrustTrack(
        temporal_model=model.temporal_tracker,
        device=device,
        association_threshold=cfg["association_threshold"],
        birth_confidence=cfg["birth_confidence"],
        max_missed=cfg["max_missed"],
        dormant_retention=cfg["dormant_retention"]
    )

    return detector, model.identity_encoder, preprocess, tracker, device, cfg


@torch.inference_mode()
def extract_embeddings(image, boxes, encoder, preprocess, device):
    H, W = image.shape[:2]
    crops, indices = [], []

    for i, box in enumerate(boxes):
        x1, y1, x2, y2 = box
        x1 = max(0, int(np.floor(x1)))
        y1 = max(0, int(np.floor(y1)))
        x2 = min(W, int(np.ceil(x2)))
        y2 = min(H, int(np.ceil(y2)))

        if x2 <= x1 or y2 <= y1:
            continue

        crop = cv2.cvtColor(
            image[y1:y2, x1:x2],
            cv2.COLOR_BGR2RGB
        )

        crops.append(preprocess(Image.fromarray(crop)))
        indices.append(i)

    if not crops:
        return (
            np.zeros((0, 128), dtype=np.float32),
            np.zeros(0, dtype=np.int64)
        )

    outputs = []

    for start in range(0, len(crops), 64):
        batch = torch.stack(
            crops[start:start + 64]
        ).to(device)

        z = F.normalize(
            encoder(batch).float(), dim=-1
        )

        outputs.append(z.cpu().numpy())

    return (
        np.concatenate(outputs).astype(np.float32),
        np.asarray(indices, dtype=np.int64)
    )


def frames_from_input(path):
    path = Path(path)

    if path.is_dir():
        images = sorted(
            list(path.glob("*.jpg"))
            + list(path.glob("*.png"))
            + list(path.glob("*.jpeg"))
        )
        assert images, f"No image frames in {path}"

        for image_path in images:
            image = cv2.imread(str(image_path))
            if image is None:
                raise RuntimeError(
                    f"Cannot read {image_path}"
                )

            frame_id = (
                int(image_path.stem)
                if image_path.stem.isdigit()
                else None
            )
            yield frame_id, image

    else:
        cap = cv2.VideoCapture(str(path))
        if not cap.isOpened():
            raise RuntimeError(
                f"Cannot open video: {path}"
            )

        frame_number = 0
        try:
            while True:
                ok, image = cap.read()
                if not ok:
                    break
                frame_number += 1
                yield frame_number, image
        finally:
            cap.release()


def run(args):
    detector, encoder, preprocess, tracker, device, cfg = (
        load_pipeline(args.config)
    )

    records = []
    total_frames = 0
    width = height = None
    last_frame = 0

    for index, (frame_id, image) in enumerate(
        frames_from_input(args.input), 1
    ):
        if frame_id is None:
            frame_id = index

        if frame_id <= last_frame:
            raise ValueError(
                "Frame numbers must increase."
            )

        last_frame = frame_id
        height, width = image.shape[:2]

        detection = detector.predict(
            source=image,
            imgsz=cfg["detector_imgsz"],
            conf=cfg["detector_confidence"],
            classes=[0],
            verbose=False
        )[0]

        boxes = detection.boxes.xyxy.cpu().numpy().astype(
            np.float32
        )

        scores = detection.boxes.conf.cpu().numpy().astype(
            np.float32
        )

        embeddings, keep = extract_embeddings(
            image, boxes, encoder, preprocess, device
        )

        observations = {
            "boxes": boxes[keep],
            "scores": scores[keep],
            "embeddings": embeddings
        }

        records.extend(
            tracker.step(
                frame_id, observations, width, height
            )
        )

        total_frames += 1

        if total_frames % 100 == 0:
            print(
                f"Processed {total_frames} frames | "
                f"Records {len(records)}",
                flush=True
            )

    if total_frames == 0:
        raise RuntimeError("No frames processed.")

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    columns = [
        "frame", "track_id", "cx", "cy", "w", "h"
    ]

    df = pd.DataFrame(records, columns=columns)
    df.to_csv(
        output_dir / "tracks.csv",
        index=False
    )

    mot = pd.DataFrame({
        "frame": df["frame"].astype(int),
        "id": df["track_id"].astype(int),
        "x": (df["cx"] - df["w"]/2) * width,
        "y": (df["cy"] - df["h"]/2) * height,
        "w": df["w"] * width,
        "h": df["h"] * height,
        "conf": 1.0,
        "world_x": -1,
        "world_y": -1,
        "world_z": -1
    })

    mot.to_csv(
        output_dir / "motchallenge.txt",
        header=False,
        index=False,
        float_format="%.6f"
    )

    summary = {
        "frames": total_frames,
        "records": len(df),
        "unique_ids": int(df["track_id"].nunique()),
        "tracker_stats": tracker.statistics
    }

    with open(output_dir / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    print("\nUNIFIED TRUSTTRACK COMPLETED")
    print(json.dumps(summary, indent=2))
    print("Output:", output_dir)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument(
        "--config",
        default=str(
            BASE / "final_inference_config.json"
        )
    )

    run(parser.parse_args())
