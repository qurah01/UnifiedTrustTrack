from torchvision import transforms
from PIL import Image
# Original Unified TrustTrack component definitions
# Exported from the user's saved implementation notebook.
# Do not edit during baseline finalization.

import math
import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

from torchvision.models import (
    resnet18,
    ResNet18_Weights
)
from dataclasses import dataclass, field
from collections import deque, defaultdict
from scipy.optimize import linear_sum_assignment



class TrustTrackIdentityEncoder(nn.Module):
    def __init__(self, embedding_dim=128):
        super().__init__()

        backbone = resnet18(
            weights=ResNet18_Weights.DEFAULT
        )

        # Freeze early visual features.
        for p in backbone.parameters():
            p.requires_grad = False

        # Fine-tune the final visual block.
        for p in backbone.layer4.parameters():
            p.requires_grad = True

        backbone.fc = nn.Identity()

        self.backbone = backbone

        self.embedding_head = nn.Sequential(
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, embedding_dim)
        )

    def forward(self, images):
        features = self.backbone(images)
        embeddings = self.embedding_head(features)
        return F.normalize(embeddings, dim=-1)



class TrustTrackV11(nn.Module):
    def __init__(self, embedding_dim=128, hidden_dim=128):
        super().__init__()

        self.history_projection = nn.Sequential(
            nn.Linear(embedding_dim + 5, hidden_dim),
            nn.LayerNorm(hidden_dim)
        )

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim,
            nhead=4,
            dim_feedforward=256,
            dropout=0.1,
            batch_first=True,
            activation="gelu",
            norm_first=True
        )

        self.temporal_encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=2,
            enable_nested_tensor=False
        )

        # Historical identity + candidate appearance
        # + predictive consistency evidence.
        self.consistency_network = nn.Sequential(
            nn.Linear(hidden_dim + 128 + 8, 128),
            nn.LayerNorm(128),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(128, 64),
            nn.GELU()
        )

        self.association_head = nn.Linear(64, 1)
        self.trust_head = nn.Linear(64, 1)

    def forward(
        self,
        history_embeddings,
        history_boxes,
        history_times,
        candidate_embeddings,
        candidate_boxes
    ):
        B = history_embeddings.shape[0]

        # Historical appearance + geometry + time.
        tokens = torch.cat([
            history_embeddings,
            history_boxes,
            history_times.unsqueeze(-1)
        ], dim=-1)

        tokens = self.history_projection(tokens)
        encoded = self.temporal_encoder(tokens)

        # Contextualized track representation.
        track_state = encoded[:, -1]

        # Persistent appearance memory prototype.
        memory = F.normalize(
            history_embeddings.mean(dim=1),
            dim=-1
        )

        candidate_embeddings = F.normalize(
            candidate_embeddings,
            dim=-1
        )

        # Constant-velocity prediction using actual
        # sampling intervals, not assuming dt = 1.
        dt_history = (
            history_times[:, -1] -
            history_times[:, -2]
        ).clamp(min=1e-4)

        dt_future = (-history_times[:, -1]).clamp(min=1e-4)

        velocity = (
            history_boxes[:, -1] -
            history_boxes[:, -2]
        ) / dt_history.unsqueeze(-1)

        predicted_box = (
            history_boxes[:, -1]
            + velocity * dt_future.unsqueeze(-1)
        )

        # Geometric discrepancy in box-size units.
        scale = history_boxes[:, -1, 2:4].clamp(min=0.01)

        center_residual = (
            candidate_boxes[:, :2] -
            predicted_box[:, :2]
        ) / scale

        size_residual = (
            candidate_boxes[:, 2:4] -
            predicted_box[:, 2:4]
        ) / scale

        # Cosine appearance disagreement.
        short_distance = (
            1.0 - F.cosine_similarity(
                history_embeddings[:, -1],
                candidate_embeddings,
                dim=-1
            )
        ).unsqueeze(-1)

        memory_distance = (
            1.0 - F.cosine_similarity(
                memory,
                candidate_embeddings,
                dim=-1
            )
        ).unsqueeze(-1)

        # 8 consistency features:
        # 2 center, 2 size, short appearance,
        # memory appearance, gap, center magnitude.
        evidence = torch.cat([
            center_residual.clamp(-10, 10),
            size_residual.clamp(-10, 10),
            short_distance,
            memory_distance,
            dt_future.unsqueeze(-1),
            torch.linalg.vector_norm(
                center_residual, dim=-1,
                keepdim=True
            ).clamp(max=10)
        ], dim=-1)

        assert evidence.shape == (B, 8)

        joint = self.consistency_network(
            torch.cat([
                track_state,
                candidate_embeddings,
                evidence
            ], dim=-1)
        )

        association_logit = (
            self.association_head(joint).squeeze(-1)
        )

        trust_logit = (
            self.trust_head(joint).squeeze(-1)
        )

        trust = torch.sigmoid(trust_logit)

        # Differentiable long-term appearance update.
        updated_memory = F.normalize(
            (1.0 - trust.unsqueeze(-1)) * memory
            + trust.unsqueeze(-1) * candidate_embeddings,
            dim=-1
        )

        return {
            "association_logit": association_logit,
            "trust_logit": trust_logit,
            "trust": trust,
            "updated_memory": updated_memory,
            "memory": memory
        }



class TrustTrackV13(nn.Module):
    def __init__(self, identity_encoder, temporal_tracker):
        super().__init__()
        self.identity_encoder = identity_encoder
        self.temporal_tracker = temporal_tracker

    def forward(self, images, history_boxes,
                history_times, candidate_boxes):
        B, T, C, H, W = images.shape

        # Joint image feature extraction:
        # gradients reach the identity encoder.
        embeddings = self.identity_encoder(
            images.reshape(B*T, C, H, W)
        ).reshape(B, T, 128)

        output = self.temporal_tracker(
            embeddings[:, :4],
            history_boxes,
            history_times,
            embeddings[:, 4],
            candidate_boxes
        )

        return output



@dataclass
class TrustTrackState:
    track_id: int
    box: np.ndarray
    embedding: np.ndarray
    last_frame: int
    velocity: np.ndarray = field(
        default_factory=lambda: np.zeros(2, dtype=np.float32)
    )
    observations: deque = field(
        default_factory=lambda: deque(maxlen=4)
    )
    identity_memory: np.ndarray = None
    missed: int = 0
    status: str = "active"
    trust: float = 1.0



class UnifiedTrustTrack:
    def __init__(
        self,
        temporal_model,
        device,
        association_threshold=0.60,
        birth_confidence=0.50,
        max_missed=15,
        dormant_retention=30
    ):
        self.model = temporal_model.to(device).eval()
        self.device = device

        self.association_threshold = association_threshold
        self.birth_confidence = birth_confidence
        self.max_missed = max_missed
        self.dormant_retention = dormant_retention

        self.tracks = {}
        self.next_id = 1
        self.statistics = {
            "births": 0,
            "associations": 0,
            "reactivations": 0,
            "terminated": 0
        }

    @staticmethod
    def normalize_embedding(embedding):
        embedding = np.asarray(
            embedding, dtype=np.float32
        )
        return embedding / max(
            np.linalg.norm(embedding), 1e-8
        )

    @staticmethod
    def normalize_box(xyxy, width, height):
        x1, y1, x2, y2 = xyxy
        return np.array([
            (x1 + x2) / (2 * width),
            (y1 + y2) / (2 * height),
            (x2 - x1) / width,
            (y2 - y1) / height
        ], dtype=np.float32)

    def predict(self, track, frame):
        gap = max(0, frame - track.last_frame)

        predicted = track.box.copy()
        predicted[:2] += track.velocity * gap
        predicted[:2] = np.clip(
            predicted[:2], 0.0, 1.0
        )
        return predicted

    def candidate_score_matrix(
        self, tracks, detections, frame
    ):
        n = len(tracks)
        m = len(detections)

        scores = np.full(
            (n, m), -1.0, dtype=np.float32
        )

        if n == 0 or m == 0:
            return scores

        histories_emb = []
        histories_box = []
        histories_time = []
        candidates_emb = []
        candidates_box = []
        pair_indices = []

        for i, track in enumerate(tracks):
            predicted = self.predict(track, frame)

            history = list(track.observations)

            if not history:
                continue

            # Pad short track histories to four entries.
            history = (
                [history[0]] * max(0, 4 - len(history))
                + history[-4:]
            )[-4:]

            for j, det in enumerate(detections):
                # Spatial gating before neural scoring.
                center_distance = np.linalg.norm(
                    predicted[:2] - det["box"][:2]
                )

                track_scale = max(
                    0.07,
                    3.0 * np.sqrt(
                        max(predicted[2] * predicted[3], 1e-5)
                    )
                )

                if center_distance > track_scale:
                    continue

                histories_emb.append(
                    np.stack([x[2] for x in history])
                )
                histories_box.append(
                    np.stack([x[1] for x in history])
                )
                histories_time.append(
                    np.array([
                        (x[0] - frame) / 30.0
                        for x in history
                    ], dtype=np.float32)
                )
                candidates_emb.append(det["embedding"])
                candidates_box.append(det["box"])
                pair_indices.append((i, j))

        if not pair_indices:
            return scores

        with torch.inference_mode():
            for start in range(0, len(pair_indices), 512):
                end = min(
                    start + 512, len(pair_indices)
                )

                def tensor(items):
                    return torch.as_tensor(
                        np.asarray(
                            items[start:end],
                            dtype=np.float32
                        ),
                        device=self.device
                    )

                output = self.model(
                    tensor(histories_emb),
                    tensor(histories_box),
                    tensor(histories_time),
                    tensor(candidates_emb),
                    tensor(candidates_box)
                )

                probabilities = torch.sigmoid(
                    output["association_logit"]
                    .reshape(-1).float()
                ).cpu().numpy()

                for k, probability in enumerate(
                    probabilities, start
                ):
                    i, j = pair_indices[k]
                    scores[i, j] = float(probability)

        return scores

    def create_track(self, detection, frame):
        track_id = self.next_id
        self.next_id += 1

        embedding = detection["embedding"].copy()

        track = TrustTrackState(
            track_id=track_id,
            box=detection["box"].copy(),
            embedding=embedding,
            last_frame=frame,
            identity_memory=embedding.copy()
        )

        track.observations.append((
            frame,
            detection["box"].copy(),
            embedding.copy()
        ))

        self.tracks[track_id] = track
        self.statistics["births"] += 1

        return track

    def update_track(
        self, track, detection, frame, association_score
    ):
        previous_center = track.box[:2].copy()
        gap = max(1, frame - track.last_frame)

        observed_velocity = (
            detection["box"][:2] - previous_center
        ) / gap

        track.velocity = (
            0.6 * track.velocity
            + 0.4 * observed_velocity
        )

        # Conservative heuristic memory update.
        # This is not yet a calibrated learned trust gate.
        alpha = float(np.clip(
            detection["confidence"]
            * association_score,
            0.05, 0.80
        ))

        memory = (
            (1.0 - alpha) * track.identity_memory
            + alpha * detection["embedding"]
        )

        track.identity_memory = (
            self.normalize_embedding(memory)
        )

        if track.status == "dormant":
            self.statistics["reactivations"] += 1

        track.box = detection["box"].copy()
        track.embedding = detection["embedding"].copy()
        track.last_frame = frame
        track.missed = 0
        track.status = "active"
        track.trust = alpha

        track.observations.append((
            frame,
            track.box.copy(),
            track.embedding.copy()
        ))

        self.statistics["associations"] += 1

    def step(self, frame, observation, width, height):
        boxes = np.asarray(
            observation["boxes"],
            dtype=np.float32
        ).reshape(-1, 4)

        embeddings = np.asarray(
            observation["embeddings"],
            dtype=np.float32
        ).reshape(-1, 128)

        confidences = np.asarray(
            observation["scores"],
            dtype=np.float32
        ).reshape(-1)

        assert len(boxes) == len(embeddings) == len(confidences)

        detections = []

        for box, embedding, confidence in zip(
            boxes, embeddings, confidences
        ):
            detections.append({
                "box": self.normalize_box(
                    box, width, height
                ),
                "embedding": self.normalize_embedding(
                    embedding
                ),
                "confidence": float(confidence)
            })

        eligible_tracks = [
            track for track in self.tracks.values()
            if track.status != "terminated"
            and frame - track.last_frame <= (
                self.max_missed + self.dormant_retention
            )
        ]

        score_matrix = self.candidate_score_matrix(
            eligible_tracks, detections, frame
        )

        matched_tracks = set()
        matched_detections = set()

        if score_matrix.size:
            # Block invalid pairs before Hungarian assignment.
            costs = np.where(
                score_matrix >= self.association_threshold,
                1.0 - score_matrix,
                1e6
            )

            rows, cols = linear_sum_assignment(costs)

            for i, j in zip(rows, cols):
                if costs[i, j] >= 1e6:
                    continue

                track = eligible_tracks[i]

                self.update_track(
                    track,
                    detections[j],
                    frame,
                    float(score_matrix[i, j])
                )

                matched_tracks.add(track.track_id)
                matched_detections.add(j)

        # Transition unmatched tracks through their lifecycle.
        for track in eligible_tracks:
            if track.track_id in matched_tracks:
                continue

            track.missed = frame - track.last_frame

            if track.missed > (
                self.max_missed + self.dormant_retention
            ):
                track.status = "terminated"
                self.statistics["terminated"] += 1
            elif track.missed > self.max_missed:
                track.status = "dormant"
            else:
                track.status = "occluded"

        # Remove terminated tracks beyond the retention period.
        for track_id, track in list(self.tracks.items()):
            if track.status == "terminated" or (
                frame - track.last_frame >
                self.max_missed + self.dormant_retention
            ):
                del self.tracks[track_id]

        # Model-free births, pending learned birth supervision.
        for j, detection in enumerate(detections):
            if j in matched_detections:
                continue

            if detection["confidence"] >= self.birth_confidence:
                self.create_track(detection, frame)

        # Emit only observed tracks, not hallucinated boxes.
        output = []

        for track in self.tracks.values():
            if (
                track.status == "active"
                and track.last_frame == frame
            ):
                cx, cy, bw, bh = track.box

                output.append({
                    "frame": int(frame),
                    "track_id": int(track.track_id),
                    "cx": float(cx),
                    "cy": float(cy),
                    "w": float(bw),
                    "h": float(bh)
                })

        return output

